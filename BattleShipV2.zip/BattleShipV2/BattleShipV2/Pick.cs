﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BattleShipV2
{
    public class Pick
    {
        //object that stores Pick information (coordinates, result, index) for the human player or the computer per round
        public int X { get; }
        public int Y { get; }

        public int Index { get; }
        public string HoM { get; }

        public Pick(int x, int y)
        {
            X = x;
            Y = y;
        }

        public Pick(int x, int y, string hom)
        {
            X = x;
            Y = y;
            HoM = hom;
        }

        public Pick(int x, int y, int index)
        {
            X = x;
            Y = y;
            Index = index;
        }

        public Pick(int x, int y, int index, string hom)
        {
            X = x;
            Y = y;
            Index = index;
            HoM = hom;
        }
    }
}
