﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BattleShipV2
{
    public class Battleship : BaseShip
    {
        public Battleship(string Name) : base(Name)
        {
            Coordinate_Y = new int[4];
            Coordinate_X = new int[4];
        }
        public Battleship()
        {
            Coordinate_Y = new int[4];
            Coordinate_X = new int[4];
        }

        public override string ShipTypeName
        {
            get { return "Battleship"; }
        }

        public override string ShipImageHorizontal
        {
            get { return "SSSS"; }
        }

        public override int ShipLength
        {
            get { return 4; }
        }
    }
}
