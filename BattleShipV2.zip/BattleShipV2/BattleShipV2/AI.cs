﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BattleShipV2
{
    class AI
    {
        private List<Pick> AIPickMemory;
        private List<Pick> AdjacentShipsMemory;
        private int Adj_Ship_Counter;
        private bool AdjacentShips;
        private List<string> AllCoordinates;
        private Random rand;
        public AI()
        {
            AIPickMemory = new List<Pick>();
            AdjacentShipsMemory = new List<Pick>();
            AllCoordinates = new List<string>();
            rand = new Random();

            Adj_Ship_Counter = 0;
            AdjacentShips = false;

            AddAllCoordinates(Board.UpperBound1D);
        }

        private void AddAllCoordinates(int BoardMaxValue)
        {
            for (var i = 0; i <= BoardMaxValue; i++)
            {
                for (var j = 0; j <= BoardMaxValue; j++)
                {
                    var CurrentValue = $"{i},{j}";
                    AllCoordinates.Add(CurrentValue);
                }
            }
        }

        private void RemovePick(int Pick)
        {
            AllCoordinates.RemoveAt(Pick);
        }

        private Pick RandomPick()
        {
            var Index = rand.Next(0, AllCoordinates.Count);
            var Pick = AllCoordinates[Index];
            var PickSplit = Pick.Split(",");

            var Random_X = Convert.ToInt32(PickSplit[0]);
            var Random_Y = Convert.ToInt32(PickSplit[1]);

            var Coordinate = new Pick(Random_X, Random_Y, Index);

            return Coordinate;
        }

        public Pick DetermineNextPick()
        {
            Pick CurrentPick;

            if (AdjacentShips == true)
            {
                if (Adj_Ship_Counter == AIPickMemory.Count)
                {
                    //reset values
                    Adj_Ship_Counter = 0;
                    AdjacentShips = false;
                    AIPickMemory.Clear();
                    CurrentPick = RandomPick();
                }
                else
                {
                    //ship was sunk last hit, add the next coordinate in AIPickMemory
                    if (AdjacentShipsMemory.Count == 0)
                    {
                        AdjacentShipsMemory.Add(AIPickMemory[Adj_Ship_Counter]);
                    }
                    CurrentPick = NextPickLogic(AdjacentShipsMemory, AdjacentShipsMemory.Count);
                }
            }
            else
            {
                CurrentPick = NextPickLogic(AIPickMemory, AIPickMemory.Count);
            }

            //var NumOfHits = CountNumberofHits(AIPickMemory);
            //var HitCoordinates = FindHits(AIPickMemory);
            //var CurrentPick = NextPickLogic(HitCoordinates, NumOfHits);
            return CurrentPick;
        }

        private Pick NextPickLogic(List<Pick> HitCoordinates, int NumOfHits)
        {
            Pick Pick;

            switch (NumOfHits)
            {
                //Check all adjacent squares and randomally pick one that has not been picked already (in AllCoordinates list)
                case 1:
                    var AdjacentSquares = FindAdjacentSquares(HitCoordinates);

                    if (AdjacentSquares.Count > 0)
                    {
                        var RanIndex = rand.Next(0, AdjacentSquares.Count);
                        Pick = new Pick(AdjacentSquares[RanIndex].X, AdjacentSquares[RanIndex].Y, AdjacentSquares[RanIndex].Index);
                    }
                    else
                    {
                        AIPickMemory.Clear();
                        Pick = RandomPick();
                    }

                    break;

                //call functions that determine the pattern horizontal or vertical, (Y or X does not change for horizontal or vertical pattern)
                //Once pattern is determined, find the far left, far right, OR far Up / far Down coordinate, depending on the pattern
                //call findleft, findright, OR fundup, finddown functions
                case var n when (n > 1 && n < Board.LargestShip):

                    var Pattern = FindPattern(HitCoordinates);
                    var MinMax = FindMinMax(HitCoordinates, Pattern);
                    var PatternOptions = FindValidDirections(HitCoordinates, MinMax, Pattern);

                    if (PatternOptions.Count > 0)
                    {
                        var RanIndex = rand.Next(0, PatternOptions.Count);
                        Pick = new Pick(PatternOptions[RanIndex].X, PatternOptions[RanIndex].Y, PatternOptions[RanIndex].Index);
                    }
                    else
                    {
                        //ships are side by side and wrong pattern was chosen earlier, call the function again with each coordinate from AIPickMemory
                        AdjacentShips = true;
                        AdjacentShipsMemory.Add(AIPickMemory[Adj_Ship_Counter]);
                        Pick = NextPickLogic(AdjacentShipsMemory, AdjacentShipsMemory.Count);
                    }
                    break;

                case var t when (t == Board.LargestShip):

                    //ships are side by side, number of hits is equal to the largest ship, but no ship has sank
                    AdjacentShips = true;
                    AdjacentShipsMemory.Add(AIPickMemory[Adj_Ship_Counter]);
                    Pick = NextPickLogic(AdjacentShipsMemory, AdjacentShipsMemory.Count);

                    break;

                default:
                    Pick = RandomPick();
                    break;
            }

            return Pick;
        }

        public void CleanUp(Pick AIResult, bool ShipSank)
        {
            RemovePick(AIResult.Index);

            if (AdjacentShips == false)
            {
                if (ShipSank)
                {
                    //Ship has sank, clear memory
                    AIPickMemory.Clear();
                }
                else
                {
                    AddPicktoAIMemory(AIResult);
                    RemoveOldPicksFromAIMemory();
                }
            }
            else
            {
                if (ShipSank)
                {
                    //ship has sank, clear AdjacentShipsMemory and increment counter for next coordinate in AIPickMemory
                    Adj_Ship_Counter++;
                    AdjacentShipsMemory.Clear();
                }
                else
                {
                    AddPicktoAdjacentShipsMemory(AIResult);
                    RemoveOldPicksFromAdjacentShipsMemory();
                }
            }
        }

        private void AddPicktoAIMemory(Pick AIResult)
        {
            if (AIResult.HoM == "HIT!")
            {
                AIPickMemory.Add(AIResult);
            }
        }

        private void AddPicktoAdjacentShipsMemory(Pick AIResult)
        {
            if (AIResult.HoM == "HIT!")
            {
                AdjacentShipsMemory.Add(AIResult);
            }
        }

        private void RemoveOldPicksFromAIMemory()
        {
            if (AIPickMemory.Count > Board.LargestShip)
            {
                AIPickMemory.RemoveAt(0);
            }
        }

        private void RemoveOldPicksFromAdjacentShipsMemory()
        {
            if (AdjacentShipsMemory.Count > Board.LargestShip)
            {
                AdjacentShipsMemory.RemoveAt(0);
            }
        }

        private bool ValidCoordinate(int[] Pick)
        {
            var Value = $"{Pick[0]},{Pick[1]}";
            if (AllCoordinates.Contains(Value))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private int[] FindLeft(int X, int Y)
        {
            var Pick_X = X;
            var Pick_Y = Y - 1;
            int[] Pick = { Pick_X, Pick_Y };
            return Pick;
        }

        private int[] FindRight(int X, int Y)
        {
            var Pick_X = X;
            var Pick_Y = Y + 1;
            int[] Pick = { Pick_X, Pick_Y };
            return Pick;
        }
        private int[] FindDown(int X, int Y)
        {
            var Pick_X = X - 1;
            var Pick_Y = Y;
            int[] Pick = { Pick_X, Pick_Y };
            return Pick;
        }

        private int[] FindUp(int X, int Y)
        {
            var Pick_X = X + 1;
            var Pick_Y = Y;
            int[] Pick = { Pick_X, Pick_Y };
            return Pick;
        }

        private int FindIndex(int[] Pick)
        {
            var Value = $"{Pick[0]},{Pick[1]}";
            var Index = AllCoordinates.IndexOf(Value);
            return Index;
        }

        //returns all adjacent squares that have not been picked yet
        private List<Pick> FindAdjacentSquares(List<Pick> Hits)
        {
            List<Pick> ValidPicks = new List<Pick>();

            //this function is only used when there is exactly one hit
            var Start_X = Hits[0].X;
            var Start_Y = Hits[0].Y;

            var Coordinates_PL = FindLeft(Start_X, Start_Y);
            var IndexOfCord_PL = FindIndex(Coordinates_PL);
            if (ValidCoordinate(Coordinates_PL))
            {
                var AI_Obj = new Pick(Coordinates_PL[0], Coordinates_PL[1], IndexOfCord_PL);
                ValidPicks.Add(AI_Obj);
            }

            var Coordinates_PR = FindRight(Start_X, Start_Y);
            var IndexOfCord_PR = FindIndex(Coordinates_PR);
            if (ValidCoordinate(Coordinates_PR))
            {
                var AI_Obj = new Pick(Coordinates_PR[0], Coordinates_PR[1], IndexOfCord_PR);
                ValidPicks.Add(AI_Obj);
            }

            var Coordinates_PD = FindDown(Start_X, Start_Y);
            var IndexOfCord_PD = FindIndex(Coordinates_PD);
            if (ValidCoordinate(Coordinates_PD))
            {
                var AI_Obj = new Pick(Coordinates_PD[0], Coordinates_PD[1], IndexOfCord_PD);
                ValidPicks.Add(AI_Obj);
            }

            var Coordinates_PU = FindUp(Start_X, Start_Y);
            var IndexOfCord_PU = FindIndex(Coordinates_PU);
            if (ValidCoordinate(Coordinates_PU))
            {
                var AI_Obj = new Pick(Coordinates_PU[0], Coordinates_PU[1], IndexOfCord_PU);
                ValidPicks.Add(AI_Obj);
            }

            return ValidPicks;
        }

        private string FindPattern(List<Pick> HitCoordinates)
        {
            string Pattern = "";
            var X = HitCoordinates[0].X;
            var Y = HitCoordinates[0].Y;
            int counter = 0;

            while (counter < HitCoordinates.Count)
            {
                if (HitCoordinates[counter].X != X)
                {
                    break;
                }
                counter++;
            }

            if (counter == HitCoordinates.Count)
            {
                Pattern = "Horiz";
                return Pattern;
            }

            counter = 0;

            while (counter < HitCoordinates.Count)
            {
                if (HitCoordinates[counter].Y != Y)
                {
                    break;
                }
                counter++;
            }

            if (counter == HitCoordinates.Count)
            {
                Pattern = "Vert";
                return Pattern;
            }

            return Pattern;
        }

        //finds the lowest and highest value in the pattern 
        private int[] FindMinMax(List<Pick> HitCoordinates, string Pattern)
        {
            var Min = int.MaxValue;
            var Max = int.MinValue;

            if (Pattern == "Vert")
            {
                //find min/max X Value
                foreach (var Val in HitCoordinates)
                {
                    Min = Math.Min(Val.X, Min);
                    Max = Math.Max(Val.X, Max);
                }
            }

            if (Pattern == "Horiz")
            {
                //find min/max Y Value
                foreach (var Val in HitCoordinates)
                {
                    Min = Math.Min(Val.Y, Min);
                    Max = Math.Max(Val.Y, Max);
                }
            }

            int[] MinMax = new int[] { Min, Max };
            return MinMax;
        }

        private List<Pick> FindValidDirections(List<Pick> HitCoordinates, int[] MinMax, string Pattern)
        {
            List<Pick> ValidPicks = new List<Pick>();

            if (Pattern == "Horiz")
            {
                var LeftCord = FindLeft(HitCoordinates[0].X, MinMax[0]);
                var IndexOfCord_L = FindIndex(LeftCord);
                if (ValidCoordinate(LeftCord))
                {
                    var AI_Obj = new Pick(LeftCord[0], LeftCord[1], IndexOfCord_L);
                    ValidPicks.Add(AI_Obj);
                }

                var RightCord = FindRight(HitCoordinates[0].X, MinMax[1]);
                var IndexOfCord_R = FindIndex(RightCord);
                if (ValidCoordinate(RightCord))
                {
                    var AI_Obj = new Pick(RightCord[0], RightCord[1], IndexOfCord_R);
                    ValidPicks.Add(AI_Obj);
                }

            }

            if (Pattern == "Vert")
            {
                var UpCord = FindUp(MinMax[1], HitCoordinates[0].Y);
                var IndexOfCord_U = FindIndex(UpCord);

                if (ValidCoordinate(UpCord))
                {
                    var AI_Obj = new Pick(UpCord[0], UpCord[1], IndexOfCord_U);
                    ValidPicks.Add(AI_Obj);
                }

                var DownCord = FindDown(MinMax[0], HitCoordinates[0].Y);
                var IndexOfCord_D = FindIndex(DownCord);

                if (ValidCoordinate(DownCord))
                {
                    var AI_Obj = new Pick(DownCord[0], DownCord[1], IndexOfCord_D);
                    ValidPicks.Add(AI_Obj);
                }
            }

            return ValidPicks;
        }
    }
}
