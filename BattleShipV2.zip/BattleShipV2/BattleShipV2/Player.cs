﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BattleShipV2
{
    public abstract class Player
    {
        public abstract void SetBoardUp();
        protected abstract IShip CreateShip(IShip Ship, string name);
        protected abstract void DrawShip(IShip Ship);
        protected abstract void SetInitialCoordinate(IShip Ship);
        protected abstract bool CheckForShipColision(IShip Ship);
        protected abstract bool CallDrawFunctions(IShip Ship, int Value);
        public abstract void TakeTurn();

        protected static bool DrawLeft(IShip Ship)
        {
            var CheckForOutOfBounds = Ship.Y_StartingPoint - (Ship.ShipLength - 1);

            if (CheckForOutOfBounds < Board.LowerBound1D)
            {
                return false;
            }

            for (int i = Ship.Coordinate_Y.Length - 1; i >= 0; i--)
            {
                Ship.Coordinate_X[i] = Ship.X_StartingPoint;
                Ship.Coordinate_Y[i] = Ship.Y_StartingPoint - i;
            }
            return true;
        }

        protected static bool DrawRight(IShip Ship)
        {
            var CheckForOutOfBounds = Ship.Y_StartingPoint + (Ship.ShipLength - 1);

            if (CheckForOutOfBounds > Board.UpperBound1D)
            {
                return false;
            }

            for (int i = 0; i < Ship.Coordinate_Y.Length; i++)
            {
                Ship.Coordinate_X[i] = Ship.X_StartingPoint;
                Ship.Coordinate_Y[i] = Ship.Y_StartingPoint + i;
            }

            return true;
        }

        protected static bool DrawUp(IShip Ship)
        {
            var CheckForOutOfBounds = Ship.X_StartingPoint - (Ship.ShipLength - 1);

            if (CheckForOutOfBounds < Board.LowerBound1D)
            {
                return false;
            }

            for (int i = Ship.Coordinate_Y.Length - 1; i >= 0; i--)
            {
                Ship.Coordinate_X[i] = Ship.X_StartingPoint - i;
                Ship.Coordinate_Y[i] = Ship.Y_StartingPoint;
            }

            return true;
        }

        protected static bool DrawDown(IShip Ship)
        {
            var CheckForOutOfBounds = Ship.X_StartingPoint + (Ship.ShipLength - 1);

            if (CheckForOutOfBounds > Board.UpperBound1D)
            {
                return false;
            }

            for (int i = 0; i < Ship.Coordinate_Y.Length; i++)
            {
                Ship.Coordinate_X[i] = Ship.X_StartingPoint + i;
                Ship.Coordinate_Y[i] = Ship.Y_StartingPoint;
            }

            return true;
        }
    }
}
