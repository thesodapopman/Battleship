﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BattleShipV2
{
    public class Destroyer : BaseShip
    {
        public Destroyer(string Name) : base(Name)
        {
            Coordinate_Y = new int[2];
            Coordinate_X = new int[2];
        }
        public Destroyer()
        {
            Coordinate_Y = new int[2];
            Coordinate_X = new int[2];
        }

        public override string ShipTypeName
        {
            get { return "Destroyer"; }
        }

        public override string ShipImageHorizontal
        {
            get { return "SS"; }
        }

        public override int ShipLength
        {
            get { return 2; }
        }
    }
}
