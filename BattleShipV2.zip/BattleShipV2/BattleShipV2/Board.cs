﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace BattleShipV2
{
    public static class Board
    {
        //Short hand for creating a private backing field and public get/set accessor on it in C#

        //Intel boards stores feedback about hits, misses, and ships that have sank (M = Miss, X = Hit, $ sank ship)
        public static object[,] HumanBoard { get; set; }
        public static string[,] IntelOnCPUBoard { get; set; }
        public static List<string> ComputerShipLocations { get; set; }


        public static object[,] ComputerBoard { get; set; }
        public static string[,] IntelOnHumanBoard { get; set; }
        public static List<string> HumanShipLocations { get; set; }


        public static int UpperBound1D { get; set; }
        public static int UpperBound2D { get; set; }

        public static int LowerBound1D { get; set; }
        public static int LowerBound2D { get; set; }

        public static int NumOfShips { get; set; }
        public static int LargestShip { get; set; }
        public static string ShipMenu { get; set; }
        public static string ShipImages { get; set; }


        public static List<IShip> ShipObjects { get; set; }


        public static void BuildBoard()
        {
            //this function will be called once per game, to build the board and set it up before play starts
            Console.WriteLine("Enter a whole number between 5 and 10 for the board size");
            Console.Write(": ");
            string UserInput = Console.ReadLine();
            var Size = ValidIntegerRange(UserInput, 5, 10);

            HumanBoard = new object[Size, Size];
            IntelOnCPUBoard = new string[Size, Size];

            ComputerBoard = new object[Size, Size];
            IntelOnHumanBoard = new string[Size, Size];

            ShipObjects = GetShipObjects();
            NumOfShips = DetermineNumberOfShips(Size);
            LargestShip = DetermineLargestShip();
            ShipMenu = GetShipMenu(ShipObjects);
            ShipImages = GetShipImages(ShipObjects);

            UpperBound1D = ComputerBoard.GetUpperBound(0);
            UpperBound2D = ComputerBoard.GetUpperBound(1);

            LowerBound1D = ComputerBoard.GetLowerBound(0);
            LowerBound2D = ComputerBoard.GetLowerBound(1);

            HumanShipLocations = new List<string>();
            ComputerShipLocations = new List<string>();

            //set all values of the board to the default value of " * "
            for (var i = 0; i <= UpperBound1D; i++)
            {
                for (var j = 0; j <= UpperBound2D; j++)
                {
                    HumanBoard[i, j] = " * ";
                    ComputerBoard[i, j] = " * ";

                    IntelOnCPUBoard[i, j] = " * ";
                    IntelOnHumanBoard[i, j] = " * ";
                }
            }
        }

        public static void DisplayScreen(object[,] Board)
        {
            //this is scalable if the board gets larger or smaller
            //display screen plus Y axis
            for (var i = 0; i <= UpperBound1D; i++)
            {
                Console.Write($"{i}|  ");
                for (var j = 0; j <= UpperBound2D; j++)
                {
                    var Type = Board[i, j].GetType();
                    //checks if there is a ship at this location, if there is put S
                    if (!Type.Equals(typeof(string)))
                    {
                        Console.Write(" S ");
                    }
                    else
                    {
                        Console.Write(Board[i, j]);
                    }
                }
                Console.WriteLine("");
            }

            //displays X axis values
            for (var j = 0; j <= UpperBound2D; j++)
            {
                if (j == 0)
                {
                    Console.WriteLine(XAxisLines());
                    Console.Write("     ");
                }
                Console.Write($"{j}  ");
            }
        }

        private static string XAxisLines()
        {
            //make X Axis horizontal line going accross
            var x = (UpperBound2D);
            var answer = "     ____";
            for (var i = 1; i < x; i++)
            {
                answer += "___";
            }
            return answer;
        }

        public static void SwapValues(int param1, int param2, string[,] Board)
        {
            //I goes down, J goes accross, switches these values making it a traditional X,Y axis grid
            Console.WriteLine(Board[param2, param1]);
        }

        public static int ValidWholeNumber(string param)
        {
            //returns a valid whole number
            bool res = false;
            int num1;

            while (res == false)
            {
                res = int.TryParse(param, out num1);
                if (res == false)
                {
                    Console.WriteLine("***Oops! Please Enter a whole number***");
                    Console.Write(": ");
                    param = Console.ReadLine();
                }
            }
            return Convert.ToInt32(param);
        }

        public static int ValidIntegerRange(string param, int LowerLimit, int UpperLimit)
        {
            //returns a valid whole number between the range of Lower and upper limit
            var PotentialNumber = ValidWholeNumber(param);

            while (PotentialNumber < LowerLimit || PotentialNumber > UpperLimit)
            {
                Console.WriteLine($"***Oops! Please Enter a number between {LowerLimit} and {UpperLimit}***");
                Console.Write(": ");
                PotentialNumber = ValidWholeNumber(Console.ReadLine());
            }
            return PotentialNumber;
        }

        private static int DetermineNumberOfShips(int size)
        {
            int ShipTotLen = 0;
            foreach (var ship in ShipObjects)
            {
                ShipTotLen += ship.ShipLength;
            }
            var AvgShipLen = ShipTotLen / ShipObjects.Count;

            var sizeSquared = (size * size);
            var NumOfShips = Convert.ToInt32(Math.Floor((sizeSquared * .40) / AvgShipLen));
            return NumOfShips;
        }

        private static int DetermineLargestShip()
        {
            int ShipTotLen = 0;

            foreach (var ship in ShipObjects)
            {
                if (ship.ShipLength > ShipTotLen)
                {
                    ShipTotLen = ship.ShipLength;
                }
            }

            return ShipTotLen;
        }


        /*****GetShipObjects, GetShipMenu, GetShipImages, GetShipTypeName are a scalable solution. The menu scales as ship classes are added.
              Not necessary for this project but a good learning experience and fun to implement!*****/

        //Get all of the ship class objects and put them into a list
        private static List<IShip> GetShipObjects()
        {

            List<IShip> ShipObjects = new List<IShip>();

            foreach (var type in Assembly.GetExecutingAssembly().GetTypes())
            {
                var ClassName = type.Name;

                if (type.IsPublic) //Only look at public types
                {
                    if (!type.IsAbstract) //Only look at non-abstract types
                    {
                        Type interfaceType = type.GetInterface("BattleShipV2.IShip");

                        if (ClassName != "IShip" && interfaceType != null && ClassName != "BaseShip")
                        {

                            var ShipInstance = Activator.CreateInstance(type) as IShip;

                            if (ShipInstance != null)
                            {
                                ShipObjects.Add(ShipInstance);
                            }
                        }
                    }
                }
            }

            return ShipObjects;
        }


        //changed to use property instead of reflection
        private static string GetShipMenu(List<IShip> ShipObjects)
        {
            //create the ShipMenu string, combining all ship names together
            string ShipMenu = "";
            for (var i = 0; i < ShipObjects.Count; i++)
            {
                ShipMenu += $"Enter {i + 1} for {ShipObjects[i].ShipTypeName} | ";
            }

            return ShipMenu;
        }

        private static string GetShipImages(List<IShip> ShipObjects)
        {
            var ShipImages = "";

            for (var i = 0; i < ShipObjects.Count; i++)
            {
                var ShipLength = ShipObjects[i].ShipLength;
                var ShipImageHoriz = ShipObjects[i].ShipImageHorizontal;
                var ShipImage = $"Length of {ShipLength}: {ShipImageHoriz}";

                var ShipName = ShipObjects[i].ShipTypeName;
                var ShipMenuItem = $"Enter {i + 1} for {ShipName}";
                int SMILen = ShipMenuItem.Length + 1;
                var ShipPadding = ShipImage.PadRight(SMILen);

                ShipImages += ShipPadding.Insert(SMILen, "| ");
            }

            return ShipImages;
        }

        public static string GetShipName(int X, int Y, string Player)
        {
            Type ShipType;
            PropertyInfo ShipNameProperty;
            string name;

            //fix this
            if (Player == "HUMAN")
            {
                ShipType = ComputerBoard[X, Y].GetType();
                ShipNameProperty = ShipType.GetProperty("Name");
                name = ShipNameProperty.GetValue(ComputerBoard[X, Y], null).ToString();
                return name;
            }
            else
            {
                ShipType = HumanBoard[X, Y].GetType();
                ShipNameProperty = ShipType.GetProperty("Name");
                name = ShipNameProperty.GetValue(HumanBoard[X, Y], null).ToString();
                return name;
            }
        }

        public static bool DuplicatePick(Pick CurrentPick)
        {
            if (IntelOnCPUBoard[CurrentPick.X, CurrentPick.Y].ToString() != " * ")
            {
                return true;
            }
            return false;
        }

        public static string HitOrMiss(object[,] Board, Pick CurrentPick)
        {
            //if a ship is at this location, return hit, else return miss
            var Type = Board[CurrentPick.X, CurrentPick.Y].GetType();

            if (!Type.Equals(typeof(string)))
            {
                return "HIT!";
            }
            else
            {
                return "MISS";
            }
        }

        public static void UpdateIntelOnBoard(object[,] Board, Pick CurrentPick, string BoardIntel)
        {
            //i did this so i can call the hit or miss function from main and get feedback from it that can be combined into a string
            var HorMString = HitOrMiss(Board, CurrentPick);
            bool HorM;

            if (HorMString == "HIT!")
            {
                HorM = true;
            }
            else
            {
                HorM = false;
            }

            //X = HIT, M = MISS
            if (HorM)
            {
                //HIT
                if (BoardIntel == "Human")
                {
                    //update intel on Computer board for the human
                    IntelOnCPUBoard[CurrentPick.X, CurrentPick.Y] = " X ";
                }
                else
                {
                    //update intel on Human board for the CPU
                    IntelOnHumanBoard[CurrentPick.X, CurrentPick.Y] = " X ";
                }
            }
            else
            {
                //MISS
                if (BoardIntel == "Human")
                {
                    IntelOnCPUBoard[CurrentPick.X, CurrentPick.Y] = " M ";
                }
                else
                {
                    IntelOnHumanBoard[CurrentPick.X, CurrentPick.Y] = " M ";
                }
            }
        }

        public static void GetAllShipLocations()
        {
            //loop through all permutations of the board, add all coordinates where a ship is located to two lists (one for computer, one for human)
            for (var i = 0; i <= UpperBound1D; i++)
            {
                for (var j = 0; j <= UpperBound2D; j++)
                {
                    var Type = ComputerBoard[i, j].GetType();
                    var Type2 = HumanBoard[i, j].GetType();

                    //checks if there is a ship at this location, if there is add it to a list
                    if (!Type.Equals(typeof(string)))
                    {
                        var Coord = $"{i}{j}";
                        ComputerShipLocations.Add(Coord);
                    }

                    if (!Type2.Equals(typeof(string)))
                    {
                        var Coord2 = $"{i}{j}";
                        HumanShipLocations.Add(Coord2);
                    }
                }
            }
        }

        public static void RemoveShipLocation(Pick CurrentPick, string Player)
        {
            var Coord = $"{CurrentPick.X}{CurrentPick.Y}";

            //human player would be guessing the computers coordinate list, check for Player and a hit
            if (Player == "HUMAN" && IntelOnCPUBoard[CurrentPick.X, CurrentPick.Y].ToString() == " X ")
            {
                foreach (var value in ComputerShipLocations)
                {
                    if (value == Coord)
                    {
                        ComputerShipLocations.Remove(value);
                        break;
                    }
                }
            }

            //computer player would be guessing the human coordinate list, check for Player and a hit
            if (Player != "HUMAN" && IntelOnHumanBoard[CurrentPick.X, CurrentPick.Y].ToString() == " X ")
            {
                foreach (var value in HumanShipLocations)
                {
                    if (value == Coord)
                    {
                        HumanShipLocations.Remove(value);
                        break;
                    }
                }
            }
        }

        public static bool CheckIfShipSank(Pick CurrentPick, string Player)
        {
            //gets the coordinates of the ship passed to it
            Type ShipType;
            PropertyInfo ShipNameProperty;
            dynamic X_Cord;
            dynamic Y_Cord;

            if (Player == "HUMAN")
            {
                ShipType = ComputerBoard[CurrentPick.X, CurrentPick.Y].GetType();
                ShipNameProperty = ShipType.GetProperty("Coordinate_X");
                X_Cord = ShipNameProperty.GetValue(ComputerBoard[CurrentPick.X, CurrentPick.Y], null);

                ShipType = ComputerBoard[CurrentPick.X, CurrentPick.Y].GetType();
                ShipNameProperty = ShipType.GetProperty("Coordinate_Y");
                Y_Cord = ShipNameProperty.GetValue(ComputerBoard[CurrentPick.X, CurrentPick.Y], null);
            }
            else
            {
                ShipType = HumanBoard[CurrentPick.X, CurrentPick.Y].GetType();
                ShipNameProperty = ShipType.GetProperty("Coordinate_X");
                X_Cord = ShipNameProperty.GetValue(HumanBoard[CurrentPick.X, CurrentPick.Y], null);

                ShipType = HumanBoard[CurrentPick.X, CurrentPick.Y].GetType();
                ShipNameProperty = ShipType.GetProperty("Coordinate_Y");
                Y_Cord = ShipNameProperty.GetValue(HumanBoard[CurrentPick.X, CurrentPick.Y], null);
            }

            //checks if the ship is still floating or not
            var answer = ShipSankLoop(X_Cord, Y_Cord, Player);

            //if the ship did sink, update the symbols to $, to indicate to the user that the ship has sunk
            if (answer)
            {
                UpdateSinkingShip(X_Cord, Y_Cord, Player);
            }
            return answer;
        }

        private static bool ShipSankLoop(int[] X, int[] Y, string Player)
        {
            int Index;
            for (var i = 0; i < X.Length; i++)
            {
                var Cord = $"{X[i]}{Y[i]}";

                if (Player == "HUMAN")
                {
                    Index = ComputerShipLocations.IndexOf(Cord);
                }
                else
                {
                    Index = HumanShipLocations.IndexOf(Cord);
                }

                if (Index == -1)
                {
                    continue;
                }
                else
                {
                    //ship is still floating
                    return false;
                }
            }
            return true;
        }

        private static void UpdateSinkingShip(int[] X, int[] Y, string Player)
        {
            for (var i = 0; i < X.Length; i++)
            {
                if (Player == "HUMAN")
                {
                    IntelOnCPUBoard[X[i], Y[i]] = " $ ";
                }
                else
                {
                    IntelOnHumanBoard[X[i], Y[i]] = " $ ";
                }
            }
        }
    }
}
