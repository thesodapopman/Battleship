﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BattleShipV2
{
    public abstract class BaseShip : IShip
    {
        public string Name { get; set; }

        public abstract int ShipLength { get; }

        public abstract string ShipImageHorizontal { get; }

        public abstract string ShipTypeName { get; }

        public int[] Coordinate_X { get; set; }
        public int[] Coordinate_Y { get; set; }

        public int X_StartingPoint { get; set; }
        public int Y_StartingPoint { get; set; }

        //name comes from player directly
        public BaseShip(string name)
        {
            Name = name;
        }

        public BaseShip()
        {

        }
    }
}
