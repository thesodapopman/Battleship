﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BattleShipV2
{
    public interface IShip
    {
        string Name { get; set; }

        int ShipLength { get; }

        string ShipImageHorizontal { get; }

        string ShipTypeName { get; }

        int[] Coordinate_X { get; set; }
        int[] Coordinate_Y { get; set; }

        int X_StartingPoint { get; set; }
        int Y_StartingPoint {get; set;}
    }
}
