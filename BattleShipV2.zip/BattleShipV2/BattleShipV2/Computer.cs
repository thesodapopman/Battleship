﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace BattleShipV2
{
    public class Computer : Player
    {
        #region private fields
        private Random rand;

        //valid directions a ship can go given its starting point
        private List<int> ValidDrawDirections;

        //all combinations of coordinates on the board
        private List<int> PermutationsX;
        private List<int> PermutationsY;

        //AI object instance that will be used when computer takes its turn
        private AI AI_Brain;
        #endregion

        #region Properties
        //Computer player is trying to sink human ships, keep track of how many ships they need to sink
        public int HumanShipCount { get; set; }
        #endregion

        public Computer()
        {
            //initialize fields
            ValidDrawDirections = new List<int>();
            rand = new Random();
            PermutationsX = new List<int>();
            PermutationsY = new List<int>();
            AI_Brain = new AI();
            HumanShipCount = Board.NumOfShips;

            //set permutation values
            for (var i = 0; i <= Board.UpperBound1D; i++)
            {
                for (var j = 0; j <= Board.UpperBound2D; j++)
                {
                    PermutationsY.Add(i);
                    PermutationsX.Add(j);
                }
            }
        }

        public override void SetBoardUp()
        {
            var TotalShips = Board.NumOfShips;

            while (TotalShips > 0)
            {
                var RandomShip = rand.Next(0, Board.ShipObjects.Count);
                var Ship = CreateShip(Board.ShipObjects[RandomShip], "");
                DrawShip(Ship);
                ValidDrawDirections.Clear();
                TotalShips--;
            }
        }

        protected override IShip CreateShip(IShip Ship, string name)
        {
            //get the ship type
            var ShipType = Ship.GetType();

            //get the constructor with no parameters
            var Constructor = ShipType.GetConstructor(Type.EmptyTypes);

            //create a new ship object of the given ship type
            object ShipOBJ = Constructor.Invoke(new object[] { });

            return (IShip)ShipOBJ;
        }

        protected override void DrawShip(IShip Ship)
        {
            //randomly place the ship on the board, and find all possible directions that are legal to draw it
            CreateDrawDirections(Ship);

            //from the list of valid draw directions, pick one
            PickDrawDirection(Ship);

            //draw the ship on the board
            for (var i = 0; i < Ship.ShipLength; i++)
            {
                Board.ComputerBoard[Ship.Coordinate_X[i], Ship.Coordinate_Y[i]] = Ship;

                //need to delete the coordinates of the ship from permutation arrays, so a new ship will not overlap with their starting point
                for (var j = 0; j < PermutationsX.Count; j++)
                {
                    if (Ship.Coordinate_Y[i] == PermutationsY[j] && Ship.Coordinate_X[i] == PermutationsX[j])
                    {
                        PermutationsX.RemoveAt(j);
                        PermutationsY.RemoveAt(j);
                    }
                }
            }
        }

        private void CreateDrawDirections(IShip Ship)
        {
            /*Check all possible draw directions and make sure no ship is at those locations already. 
              If no ship is at those locations, add that location as a possible draw direction to a list
              if no draw direction is valid, remove that starting point, call the function again */

            SetInitialCoordinate(Ship);

            for (int j = 0; j < 4; j++)
            {
                //Check to see if drawing in this direction is inside the board (not out of bounds)
                var ValidDraw = CallDrawFunctions(Ship, j);

                if (ValidDraw == false)
                {
                    continue;
                }

                //Check for a ship collision
                var ColisionCheck = CheckForShipColision(Ship);

                if (ColisionCheck)
                {
                    continue;
                }

                //no colision, not out of bounds, this is a valid input, add it to the list of possible draw directions
                ValidDrawDirections.Add(j);
            }

            //all draw directions are not valid, delete the starting coordinate, call the function again.
            if (ValidDrawDirections.Count == 0)
            {
                DeleteInitialCoordinate(Ship);
                CreateDrawDirections(Ship);
            }
        }

        //Picks a random valid draw direction for the ship
        private void PickDrawDirection(IShip Ship)
        {
            var Index = rand.Next(0, ValidDrawDirections.Count);
            var Value = ValidDrawDirections[Index];
            CallDrawFunctions(Ship, Value);
        }

        private int GenerateRandomNumber()
        {
            return rand.Next(0, PermutationsX.Count);
        }

        //removes the ships starting location
        private void DeleteInitialCoordinate(IShip Ship)
        {
            for (var k = 0; k < PermutationsX.Count; k++)
            {
                if (Ship.Y_StartingPoint == PermutationsY[k] && Ship.X_StartingPoint == PermutationsX[k])
                {
                    PermutationsX.RemoveAt(k);
                    PermutationsY.RemoveAt(k);
                }
            }
        }

        protected override void SetInitialCoordinate(IShip Ship)
        {
            //Computer randomly sets the initial starting coordinate for the ship
            var RandomIndex = GenerateRandomNumber();
            Ship.X_StartingPoint = PermutationsX[RandomIndex];
            Ship.Y_StartingPoint = PermutationsY[RandomIndex];
        }

        protected override bool CheckForShipColision(IShip Ship)
        {
            for (var i = 0; i < Ship.ShipLength; i++)
            {
                var Type = Board.ComputerBoard[Ship.Coordinate_X[i], Ship.Coordinate_Y[i]].GetType();

                if (!Type.Equals(typeof(string)))
                {
                    //ship already at this coordinate
                    return true;
                }
            }
            return false;
        }

        protected override bool CallDrawFunctions(IShip Ship, int Value)
        {
            bool ValidDrawDirection = false;

            switch (Value)
            {
                case 0:
                    ValidDrawDirection = DrawLeft(Ship);
                    break;
                case 1:
                    ValidDrawDirection = DrawRight(Ship);
                    break;
                case 2:
                    ValidDrawDirection = DrawUp(Ship);
                    break;
                case 3:
                    ValidDrawDirection = DrawDown(Ship);
                    break;
            }

            return ValidDrawDirection;
        }

        public override void TakeTurn()
        {
            Console.Clear();
            Console.WriteLine("COMPUTERS TURN");
            var CPUPick = AI_Brain.DetermineNextPick();
            Board.UpdateIntelOnBoard(Board.HumanBoard, CPUPick, "CPU");
            Board.RemoveShipLocation(CPUPick, "CPU");

            //display pick to user
            Console.WriteLine();
            Thread.Sleep(1000);
            Console.WriteLine($"The Computer Picked: ({CPUPick.X}, {CPUPick.Y})");
            Thread.Sleep(2000);
            Console.WriteLine();

            //Result
            var Result = Board.HitOrMiss(Board.HumanBoard, CPUPick);
            bool ShipSank = false;

            if (Result == "HIT!")
            {
                //if a ship was hit, get the name of the ship
                var ShipName = Board.GetShipName(CPUPick.X, CPUPick.Y, "CPU");
                Console.WriteLine($"{ShipName} was hit at ({CPUPick.X}, {CPUPick.Y})!");

                //Check if the ship is still floating
                ShipSank = Board.CheckIfShipSank(CPUPick, "CPU");

                if (ShipSank)
                {
                    Console.WriteLine($"{ShipName} sunk!");
                    HumanShipCount--;
                }
            }
            else
            {
                Console.WriteLine($"({CPUPick.X}, {CPUPick.Y}) was a {Result}");
            }

            //clean up for AI pick
            var AIResult = new Pick(CPUPick.X, CPUPick.Y, CPUPick.Index, Result);
            AI_Brain.CleanUp(AIResult, ShipSank);

            Console.WriteLine();
            Console.WriteLine("YOUR BOARD");
            Console.WriteLine($"Number of Ships Left: {HumanShipCount}");
            Console.WriteLine();

            Board.DisplayScreen(Board.IntelOnHumanBoard);
            Console.WriteLine();
        }
    }
}
