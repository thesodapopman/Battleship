﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace BattleShipV2
{
    public class Human : Player
    {
        //Human Player is trying to sink computer ships, so they keep track of how many ships they need to sink still
        public int ComputerShipCount { get; set; }

        public Human()
        {
            ComputerShipCount = Board.NumOfShips;
        }

        //This function goes through the process of letting the player pick their ships, name them, and place them on the board.
        public override void SetBoardUp()
        {
            var ShipMenu = Board.ShipMenu;
            var ShipImages = Board.ShipImages;
            var TotalShips = Board.NumOfShips;
            
            //ask user to pick ship types, name them and draw them
            while (TotalShips > 0)
            {
                Console.WriteLine();
                Console.WriteLine("PICK YOUR SHIPS FOR BATTLE");
                Console.WriteLine($"Number of picks left: {TotalShips}");
                Console.WriteLine(ShipMenu);
                Console.WriteLine(ShipImages);
                Console.Write(": ");
                var InitialPick = Console.ReadLine();
                var Pick = Board.ValidIntegerRange(InitialPick, 1, Board.ShipObjects.Count);

                //menu starts at 1, so need to subtract 1 from the pick
                var ShipType = Board.ShipObjects[Pick - 1].ShipTypeName;

                Console.WriteLine();
                Console.WriteLine($"You Chose: {ShipType}");
                Console.WriteLine($"Enter a name for your {ShipType}");
                Console.Write(": ");
                var ShipName = Console.ReadLine();

                var Ship = CreateShip(Board.ShipObjects[Pick - 1], ShipName);
                DrawShip(Ship);

                Console.WriteLine();
                Board.DisplayScreen(Board.HumanBoard);
                Console.WriteLine();

                TotalShips--;
            }
        }

        protected override IShip CreateShip(IShip Ship, string name)
        {
            //get the type
            var ShipType = Ship.GetType();

            //searches for the constructor of the object type with a string parameter
            var Constructor = ShipType.GetConstructor(new[] { typeof(string) });

            //invoke the constructor with the name parameter that was passed by the user
            object ShipOBJ = Constructor.Invoke(new object[] { name });

            //return the new ship
            return (IShip)ShipOBJ;
        }

        protected override void DrawShip(IShip Ship)
        {
            //user picks starting point for the ship
            SetInitialCoordinate(Ship);

            //pick a draw direction, check if it goes outside of the boundaries of the board, if it does pick another direction
            var ValidDraw = CallDrawFunctions(Ship, 0);

            while (ValidDraw == false)
            {
                if (ValidDraw == false)
                {
                    Console.WriteLine();
                    Console.WriteLine("***Oops! Drawing in this direction goes outside the boundaries of the board, pick another direction***");
                    Console.WriteLine();
                    Thread.Sleep(3000);
                }
                ValidDraw = CallDrawFunctions(Ship, 0);
            }

            //Check for a ship collision
            var ShipColision = CheckForShipColision(Ship);

            while (ShipColision == true)
            {
                if (ShipColision == true)
                {
                    Console.WriteLine();
                    Console.WriteLine("***Oops! A ship is already at this location. Please choose another direction***");
                    Console.WriteLine();
                    Thread.Sleep(3000);
                }

                CallDrawFunctions(Ship, 0);
                ShipColision = CheckForShipColision(Ship);
            }

            //valid input, draw the ship on the board
            for (var i = 0; i < Ship.ShipLength; i++)
            {
                //this = object instance
                Board.HumanBoard[Ship.Coordinate_X[i], Ship.Coordinate_Y[i]] = Ship;
            }
        }

        protected override void SetInitialCoordinate(IShip Ship)
        {
            Console.WriteLine("Current Board state:");
            Console.WriteLine();
            Board.DisplayScreen(Board.HumanBoard);
            Console.WriteLine();
            Console.WriteLine();

            //human selects coordinates
            Console.Write($"Enter an X Coordinate between {Board.LowerBound1D} and {Board.UpperBound1D}: ");
            var X_UserInput = Console.ReadLine();
            var X = Board.ValidIntegerRange(X_UserInput, Board.LowerBound1D, Board.UpperBound1D);

            Console.Write($"Enter a Y Coordinate between {Board.LowerBound1D} and {Board.UpperBound1D}: ");
            var Y_UserInput = Console.ReadLine();
            var Y = Board.ValidIntegerRange(Y_UserInput, Board.LowerBound1D, Board.UpperBound1D);

            Ship.X_StartingPoint = X;
            Ship.Y_StartingPoint = Y;

            var Location = Board.HumanBoard[X, Y].GetType();

            //check if there is a ship at this starting coordinate already, if there is produce an error and the board to show the user, call the function again
            if (!Location.Equals(typeof(string)))
            {
                Console.WriteLine();
                Console.WriteLine("***Oops! there is already a ship at this location, you will have to pick a new starting point***");
                Console.WriteLine();
                Thread.Sleep(2000);
                SetInitialCoordinate(Ship);
            }

            Console.WriteLine("Here is the starting point of your ship:");
            Console.WriteLine();
            Board.HumanBoard[X, Y] = Ship;
            Board.DisplayScreen(Board.HumanBoard);
            Console.WriteLine();
        }

        //this function calls draw left, right, up or down depending on user input, and returns if that direction is valid or not depending on if it goes out of the board
        protected override bool CallDrawFunctions(IShip Ship, int Value)
        {
            Console.WriteLine();
            Console.WriteLine("Enter a Draw Direction");
            Console.WriteLine($"0 = Left, 1 = Right, 2 = Up, 3 = Down");
            Console.Write(": ");
            var UserInput = Console.ReadLine();
            Value = Board.ValidIntegerRange(UserInput, 0, 3);

            bool ValidDrawDirection = false;
            switch (Value)
            {
                case 0:
                    ValidDrawDirection = DrawLeft(Ship);
                    break;
                case 1:
                    ValidDrawDirection = DrawRight(Ship);
                    break;
                case 2:
                    ValidDrawDirection = DrawUp(Ship);
                    break;
                case 3:
                    ValidDrawDirection = DrawDown(Ship);
                    break;
            }

            return ValidDrawDirection;
        }

        protected override bool CheckForShipColision(IShip Ship)
        {
            for (var i = 0; i < Ship.ShipLength; i++)
            {
                //ignore the starting point of the ship since that has already been placed and would otherwise produce a false error
                if (Ship.Coordinate_X[i] == Ship.X_StartingPoint && Ship.Coordinate_Y[i] == Ship.Y_StartingPoint)
                {
                    continue;
                }

                var Type = Board.HumanBoard[Ship.Coordinate_X[i], Ship.Coordinate_Y[i]].GetType();

                if (!Type.Equals(typeof(string)))
                {
                    //ship already at this coordinate
                    return true;
                }
            }
            return false;
        }

        public override void TakeTurn()
        {
            //human selects coordinates
            Console.Write($"Enter an X Coordinate between {Board.LowerBound1D} and {Board.UpperBound1D}: ");
            var X_UserInput = Console.ReadLine();
            var X = Board.ValidIntegerRange(X_UserInput, Board.LowerBound1D, Board.UpperBound1D);

            Console.Write($"Enter a Y Coordinate between {Board.LowerBound1D} and {Board.UpperBound1D}: ");
            var Y_UserInput = Console.ReadLine();
            var Y = Board.ValidIntegerRange(Y_UserInput, Board.LowerBound1D, Board.UpperBound1D);

            var HumanPick = new Pick(X, Y);

            //feedback to user
            Console.Clear();
            Console.WriteLine($"You Picked: ({X}, {Y})");
            Console.WriteLine();
            Thread.Sleep(2000);

            //check if the user already picked the location chosen, if so, skip to the board display
            var Duplicate = Board.DuplicatePick(HumanPick);
            if (Duplicate)
            {
                Console.WriteLine("Oops! You already picked this location!");
                Console.WriteLine();
            }

            if (!Duplicate)
            {
                //Determine Result, (hit or miss) 
                var Result = Board.HitOrMiss(Board.ComputerBoard, HumanPick);
                Console.WriteLine($"({X}, {Y}) was a {Result}");

                //Update intel on CPU board, display feedback to user about their pick
                Board.UpdateIntelOnBoard(Board.ComputerBoard, HumanPick, "Human");
                Board.RemoveShipLocation(HumanPick, "HUMAN");
                Console.WriteLine();

                //if it was a hit, Check if the ship is still floating, display feedback if a ship sank
                if (Result == "HIT!")
                {
                    var ShipSank = Board.CheckIfShipSank(HumanPick, "HUMAN");

                    if (ShipSank)
                    {
                        Console.WriteLine($"You Sunk a Ship!");
                        Console.WriteLine();
                        ComputerShipCount--;
                    }
                }
            }

            Console.WriteLine("COMPUTERS BOARD");
            Console.WriteLine($"Number of Ships Left: {ComputerShipCount}");
            Console.WriteLine();
            Board.DisplayScreen(Board.IntelOnCPUBoard);
            Console.WriteLine();
        }
    }
}
