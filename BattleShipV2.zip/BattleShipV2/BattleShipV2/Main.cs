﻿using System;
using System.Threading;

namespace BattleShipV2
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Main Menu
            var TopOffSet = (Console.WindowHeight / 2) - 8;
            Console.SetCursorPosition(0, TopOffSet);
            Console.WriteLine(CenterText("BATTLESHIP"));
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine(CenterText("1. Play Game"));
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine(CenterText("2. Quit"));
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.Write(CenterText("1 = Play Game, 2 = Quit: "));
            var UserChoice = Console.ReadLine();
            var UserNumber = Board.ValidIntegerRange(UserChoice, 1, 2);

            if (UserNumber == 2)
            {
                Environment.Exit(0);
            }

            Thread.Sleep(1000);
            Console.Clear();
            Console.SetCursorPosition(0, TopOffSet + 6);
            Console.WriteLine(CenterText("Loading Game..."));
            Thread.Sleep(2000);
            Console.Clear();
            #endregion

            StartGame(TopOffSet);
        }

        static public void StartGame(int TopOffSet)
        {
            #region PrepBeforeGameStarts
            //set the board up
            Board.BuildBoard();
            Console.Clear();

            //create computer player and set their board up
            var ComputerPlayer = new Computer();
            ComputerPlayer.SetBoardUp();

            //create human player and set their board up
            var HumanPlayer = new Human();
            HumanPlayer.SetBoardUp();

            //game variables initialized to starting values
            Board.GetAllShipLocations();
            var RoundCounter = 1;
            #endregion

            #region GamePlay
            Console.Clear();
            Console.WriteLine("LET THE BATTLE BEGIN!");
            Thread.Sleep(2000);
            Console.WriteLine();

            while (true)
            {
                Console.WriteLine("YOUR TURN");
                Console.WriteLine();
                Thread.Sleep(1000);
                Console.WriteLine($"ROUND {RoundCounter}");
                Console.WriteLine();
                Console.WriteLine($"Number of Ships Left: {HumanPlayer.ComputerShipCount}");
                Console.WriteLine();
                Board.DisplayScreen(Board.IntelOnCPUBoard);
                Console.WriteLine();
                Console.WriteLine();

                //Human takes turn
                HumanPlayer.TakeTurn();

                //check to see if the game has ended
                if (Board.ComputerShipLocations.Count == 0 || Board.HumanShipLocations.Count == 0)
                {
                    Thread.Sleep(1000);
                    Console.Clear();
                    break;
                }

                Console.WriteLine();
                Console.Write("Press any key to continue:");
                Console.ReadLine();
                Console.Clear();

                //Computer takes turn
                ComputerPlayer.TakeTurn();

                //check if the game has ended
                if (Board.ComputerShipLocations.Count == 0 || Board.HumanShipLocations.Count == 0)
                {
                    Thread.Sleep(1000);
                    Console.Clear();
                    break;
                }

                RoundCounter++;
                Console.WriteLine();
                Console.Write("Press any key to continue:");
                Console.ReadLine();
                Console.Clear();
            }
            #endregion
            //game has ended
            EndGame(TopOffSet);
        }

        public static void EndGame(int TopOffSet)
        {
            Console.SetCursorPosition(0, TopOffSet + 6);
            if (Board.ComputerShipLocations.Count == 0)
            {
                Console.WriteLine(CenterText("VICTORY"));
            }
            else
            {
                Console.WriteLine(CenterText("DEFEAT"));
            }

            Thread.Sleep(5000);
            Console.Clear();

            Console.WriteLine("FINAL BOARD STATE");
            Console.WriteLine();
            Console.WriteLine("COMPUTERS BOARD:");
            Console.WriteLine();
            Board.DisplayScreen(Board.ComputerBoard);
            Thread.Sleep(2000);

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("YOUR PICKS:");
            Console.WriteLine();
            Board.DisplayScreen(Board.IntelOnCPUBoard);
            Console.WriteLine();
            Console.WriteLine();
            Thread.Sleep(2000);

            Console.WriteLine();
            Console.WriteLine("YOUR BOARD:");
            Console.WriteLine();
            Board.DisplayScreen(Board.HumanBoard);
            Thread.Sleep(2000);

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("COMPUTERS PICKS: ");
            Console.WriteLine();
            Board.DisplayScreen(Board.IntelOnHumanBoard);
            Console.WriteLine();
            Thread.Sleep(2000);
            Console.WriteLine();

            string GameResult = "";
            if (Board.ComputerShipLocations.Count == 0)
            {
                GameResult = "VICTORY";
            }
            else
            {
                GameResult = "DEFEAT";
            }

            Console.WriteLine($"Result: {GameResult}");
            Thread.Sleep(2000);
            Console.WriteLine();
            Console.Write("Press any key to continue:");
            Console.ReadLine();

            Console.WriteLine();
            Console.WriteLine("Play Again? (Y/N)");
            var UserInput = Console.ReadLine();
            var YorN = RestartInput_YN(UserInput);

            if (YorN)
            {
                //restart the game
                StartGame(TopOffSet);
            }
            else
            {
                //exit the application
                Environment.Exit(0);
            }
        }

        #region HelperFunctionsMain
        static public bool RestartInput_YN(string input)
        {
            while (true)
            {
                var answer = input.ToUpper();

                if (answer == "Y")
                {
                    Console.Clear();
                    return true;
                }
                if (answer == "N")
                {
                    return false;
                }

                Console.WriteLine("Oops! You must enter (Y or N)");
                input = Console.ReadLine();
            }
        }

        static public string CenterText(string input)
        {
            var s = string.Format("{0," + ((Console.WindowWidth / 2) + (input.Length / 2)) + "}", input);
            return s;
        }
        #endregion
    }
}
