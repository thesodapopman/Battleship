﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BattleShipV2
{
    public class Cruiser : BaseShip
    {
        public Cruiser(string Name) : base(Name)
        {
            Coordinate_Y = new int[3];
            Coordinate_X = new int[3];
        }
        public Cruiser()
        {
            Coordinate_Y = new int[3];
            Coordinate_X = new int[3];
        }

        public override string ShipTypeName
        {
            get { return "Cruiser"; }
        }

        public override string ShipImageHorizontal
        {
            get { return "SSS"; }
        }

        public override int ShipLength
        {
            get { return 3; }
        }
    }
}
